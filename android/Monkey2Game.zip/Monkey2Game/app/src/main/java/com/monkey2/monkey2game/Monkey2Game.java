
package com.monkey2.monkey2game;

import org.libsdl.app.SDLActivity;

import android.os.*;
import android.util.*;
import android.content.res.Configuration;

import java.io.*;
import java.nio.*;
import java.net.*;
import java.util.*;
import java.text.*;
import java.lang.reflect.*;

/*
 * A sample wrapper class that just calls SDLActivity
 */
public class Monkey2Game extends SDLActivity {

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate( savedInstanceState );
    }

    protected void onDestroy(){
        super.onDestroy();
    }
}